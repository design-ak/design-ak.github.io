"""Generate Flutter theme files from tokens.json (exported from the Figma design system).

Usage: python3 generate.py <tokens.json> <out_dir>
"""
import json
import re
import sys
from pathlib import Path

HEADER = """// GENERATED FILE — do not edit by hand.
// Source: {source}
// Regenerate from the Figma variables instead of changing values here.
"""


def camel(name: str) -> str:
    parts = re.split(r"[/\s\-]+", name)
    parts = [p for p in parts if p]
    out = parts[0].lower() + "".join(p[:1].upper() + p[1:].lower() for p in parts[1:])
    return out


def argb(hex_str: str) -> str:
    h = hex_str.lstrip("#").upper()
    if len(h) == 6:
        return "0xFF" + h
    if len(h) == 8:  # RRGGBBAA -> AARRGGBB
        return "0x" + h[6:8] + h[0:6]
    raise ValueError(hex_str)


def dart_num(v: float) -> str:
    if float(v).is_integer():
        return f"{int(v)}"
    return f"{v:g}"


def gen_colors(t, source):
    cols = [(camel(n), l, d, desc, n) for n, l, d, desc in t["colors"]]
    lines = [HEADER.format(source=source), "import 'package:flutter/material.dart';", ""]
    lines += [
        "/// Semantic colour tokens (Figma collection \"Color\", modes Light / Dark).",
        "///",
        "/// Use these, never raw hex values or primitives. Access in widgets with",
        "/// `context.colors.textPrimary` (see [AppColorsContext]).",
        "@immutable",
        "class AppColors extends ThemeExtension<AppColors> {",
        "  const AppColors({",
    ]
    lines += [f"    required this.{c},"for c, *_ in cols]
    lines += ["  });", ""]
    for c, l, d, desc, n in cols:
        lines.append(f"  /// `{n}` — {desc}")
        lines.append(f"  final Color {c};")
        lines.append("")
    for mode, idx in (("light", 1), ("dark", 2)):
        lines.append(f"  /// {mode.capitalize()} mode values.")
        lines.append(f"  static const AppColors {mode} = AppColors(")
        for row in cols:
            lines.append(f"    {row[0]}: Color({argb(row[idx])}),")
        lines.append("  );")
        lines.append("")
    # copyWith
    lines.append("  @override")
    lines.append("  AppColors copyWith({")
    lines += [f"    Color? {c}," for c, *_ in cols]
    lines.append("  }) {")
    lines.append("    return AppColors(")
    lines += [f"      {c}: {c} ?? this.{c}," for c, *_ in cols]
    lines.append("    );")
    lines.append("  }")
    lines.append("")
    # lerp
    lines.append("  @override")
    lines.append("  AppColors lerp(covariant ThemeExtension<AppColors>? other, double t) {")
    lines.append("    if (other is! AppColors) return this;")
    lines.append("    return AppColors(")
    lines += [f"      {c}: Color.lerp({c}, other.{c}, t)!," for c, *_ in cols]
    lines.append("    );")
    lines.append("  }")
    lines.append("}")
    lines.append("")
    lines += [
        "/// `context.colors.bgScreen` — shorthand for the current theme's [AppColors].",
        "extension AppColorsContext on BuildContext {",
        "  AppColors get colors {",
        "    final AppColors? colors = Theme.of(this).extension<AppColors>();",
        "    assert(colors != null, 'AppColors not found: use AppTheme.light() / AppTheme.dark().');",
        "    return colors!;",
        "  }",
        "}",
        "",
    ]
    return "\n".join(lines)


def gen_spacing(t, source):
    lines = [HEADER.format(source=source), "/// Spacing scale (Figma collection \"Spacing\"). Even values only.", "///",
             "/// Use for padding, gaps and margins: `EdgeInsets.all(AppSpacing.s16)`.",
             "abstract final class AppSpacing {"]
    for v in t["spacing"]:
        lines.append(f"  static const double s{v} = {v};")
    lines += ["}", ""]
    return "\n".join(lines)


def gen_radius(t, source):
    lines = [HEADER.format(source=source), "import 'package:flutter/painting.dart';", "",
             "/// Corner radius scale (Figma collection \"Radius\").", "///",
             "/// `AppRadius.r8` for a value, `AppRadius.all(AppRadius.r8)` for a [BorderRadius].",
             "abstract final class AppRadius {"]
    for name, v in t["radius"]:
        ident = "rFull" if name == "full" else f"r{name}"
        note = " // pill / circle" if name == "full" else ""
        lines.append(f"  static const double {ident} = {v};{note}")
    lines += ["",
              "  /// Same radius on all four corners.",
              "  static BorderRadius all(double radius) => BorderRadius.all(Radius.circular(radius));",
              "",
              "  /// Top corners only — used by bottom sheets (`AppRadius.top(AppRadius.r16)`).",
              "  static BorderRadius top(double radius) => BorderRadius.vertical(top: Radius.circular(radius));",
              "}", ""]
    return "\n".join(lines)


WEIGHTS = {"Regular": "FontWeight.w400", "SemiBold": "FontWeight.w600", "Bold": "FontWeight.w700"}


def style_ident(name: str) -> str:
    n = name.replace("Heading/", "").replace("/", " ")
    return camel(n)


def gen_typography(t, source):
    f = t["fonts"]
    lines = [HEADER.format(source=source), "import 'package:flutter/painting.dart';", "",
             "/// Text styles (Figma text styles, bound to the \"Typography\" variables).",
             "///",
             "/// English renders in Roboto; Gujarati and Hindi characters fall back to",
             "/// Noto Sans Gujarati / Noto Sans Devanagari at the same size and line height.",
             "/// Styles carry no colour: apply one from [AppColors], e.g.",
             "/// `AppTypography.bodyMd.copyWith(color: context.colors.textSecondary)`.",
             "abstract final class AppTypography {",
             f"  /// Family names must match the `family:` entries in pubspec.yaml.",
             f"  static const String fontFamily = '{f['base']}';",
             f"  static const List<String> fontFamilyFallback = <String>['{f['gujarati']}', '{f['devanagari']}'];",
             ""]
    for name, weight, size, lh, ls, desc in t["textStyles"]:
        ident = style_ident(name)
        lines.append(f"  /// {name} — {size}/{lh} {weight}. {desc}.")
        lines.append(f"  static const TextStyle {ident} = TextStyle(")
        lines.append("    fontFamily: fontFamily,")
        lines.append("    fontFamilyFallback: fontFamilyFallback,")
        lines.append(f"    fontSize: {dart_num(size)},")
        lines.append(f"    height: {dart_num(lh)} / {dart_num(size)},")
        lines.append(f"    fontWeight: {WEIGHTS[weight]},")
        lines.append(f"    letterSpacing: {dart_num(ls)},")
        lines.append("    leadingDistribution: TextLeadingDistribution.even,")
        lines.append("  );")
        lines.append("")
    lines[-1:] = []
    lines += ["}", ""]
    return "\n".join(lines)


def gen_shadows(t, source):
    lines = [HEADER.format(source=source), "import 'package:flutter/painting.dart';", "",
             "/// Elevation shadows (Figma effect styles \"Elevation/*\").",
             "/// Use as `BoxDecoration(boxShadow: AppShadows.lg)`.",
             "abstract final class AppShadows {"]
    for name, layers, desc in t["shadows"]:
        ident = camel(name.replace("Elevation/", ""))
        lines.append(f"  /// {name} — {desc}")
        lines.append(f"  static const List<BoxShadow> {ident} = <BoxShadow>[")
        for x, y, blur, spread, color in layers:
            lines.append(f"    BoxShadow(color: Color({argb(color)}), offset: Offset({dart_num(x)}, {dart_num(y)}), blurRadius: {dart_num(blur)}, spreadRadius: {dart_num(spread)}),")
        lines.append("  ];")
        lines.append("")
    lines[-1:] = []
    lines += ["}", ""]
    return "\n".join(lines)


def gen_theme(t, source):
    return HEADER.format(source=source) + """import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'app_radius.dart';
import 'app_typography.dart';

/// Builds Material [ThemeData] for Light and Dark from the design tokens.
///
/// ```dart
/// MaterialApp(
///   theme: AppTheme.light(),
///   darkTheme: AppTheme.dark(),
///   themeMode: ThemeMode.system,
/// );
/// ```
///
/// Material widgets pick up the mapped [ColorScheme] and [TextTheme]; custom
/// widgets should read tokens directly via `context.colors` and [AppTypography].
abstract final class AppTheme {
  static ThemeData light() => _build(Brightness.light, AppColors.light);
  static ThemeData dark() => _build(Brightness.dark, AppColors.dark);

  static ThemeData _build(Brightness brightness, AppColors c) {
    final ColorScheme scheme = ColorScheme(
      brightness: brightness,
      primary: c.primaryDefault,
      onPrimary: c.textOnPrimary,
      primaryContainer: c.bgPrimarySubtle,
      onPrimaryContainer: c.textLink,
      secondary: c.primaryDefault,
      onSecondary: c.textOnPrimary,
      secondaryContainer: c.bgPrimarySubtle,
      onSecondaryContainer: c.textLink,
      error: c.statusErrorText,
      onError: c.bgScreen,
      errorContainer: c.statusErrorSurface,
      onErrorContainer: c.statusErrorText,
      surface: c.bgScreen,
      onSurface: c.textPrimary,
      // Material 3 dialogs, cards, menus and sheets read these container colours.
      surfaceContainerLowest: c.bgScreen,
      surfaceContainerLow: c.bgSurface,
      surfaceContainer: c.bgSurface,
      surfaceContainerHigh: c.bgSurfaceRaised,
      surfaceContainerHighest: c.bgSurfaceRaised,
      surfaceTint: Colors.transparent,
      onSurfaceVariant: c.textSecondary,
      outline: c.borderDefault,
      outlineVariant: c.borderSubtle,
      scrim: c.bgScrim,
    );

    final TextTheme textTheme = const TextTheme(
      headlineLarge: AppTypography.h1,
      headlineMedium: AppTypography.h2,
      titleLarge: AppTypography.h3,
      titleMedium: AppTypography.h4,
      bodyLarge: AppTypography.bodyMd,
      bodyMedium: AppTypography.bodySm,
      bodySmall: AppTypography.caption,
      labelLarge: AppTypography.buttonMd,
      labelMedium: AppTypography.label,
      labelSmall: AppTypography.caption,
    ).apply(bodyColor: c.textPrimary, displayColor: c.textPrimary);

    return ThemeData(
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: c.bgScreen,
      canvasColor: c.bgScreen,
      dividerColor: c.borderSubtle,
      fontFamily: AppTypography.fontFamily,
      fontFamilyFallback: AppTypography.fontFamilyFallback,
      textTheme: textTheme,
      // Keep 48px touch targets even for 24–40px tall buttons (Rule 005).
      materialTapTargetSize: MaterialTapTargetSize.padded,
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: c.bgSurfaceRaised,
        modalBackgroundColor: c.bgSurfaceRaised,
        modalBarrierColor: c.bgScrim,
        showDragHandle: true,
        dragHandleColor: c.borderDefault,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.top(AppRadius.r16)),
        clipBehavior: Clip.antiAlias,
      ),
      extensions: <ThemeExtension<dynamic>>[c],
    );
  }
}
"""


def gen_barrel(source):
    return HEADER.format(source=source) + """export 'app_colors.dart';
export 'app_radius.dart';
export 'app_shadows.dart';
export 'app_spacing.dart';
export 'app_theme.dart';
export 'app_typography.dart';
"""


def main():
    tokens = json.loads(Path(sys.argv[1]).read_text())
    out = Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    src = tokens["source"]
    files = {
        "app_colors.dart": gen_colors(tokens, src),
        "app_spacing.dart": gen_spacing(tokens, src),
        "app_radius.dart": gen_radius(tokens, src),
        "app_typography.dart": gen_typography(tokens, src),
        "app_shadows.dart": gen_shadows(tokens, src),
        "app_theme.dart": gen_theme(tokens, src),
        "theme.dart": gen_barrel(src),
    }
    for name, content in files.items():
        (out / name).write_text(content)
        print(f"{name}: {content.count(chr(10))} lines")


if __name__ == "__main__":
    main()
