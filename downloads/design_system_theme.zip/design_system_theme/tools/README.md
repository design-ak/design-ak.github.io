# Regenerating

`tokens.json` is exported from the Figma file variables and styles; `generate.py` writes `lib/theme/` from it:

    python3 tools/generate.py tools/tokens.json lib/theme

The design team normally does this and sends updated files.
