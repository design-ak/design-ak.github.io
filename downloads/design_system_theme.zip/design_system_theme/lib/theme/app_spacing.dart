// GENERATED FILE — do not edit by hand.
// Source: Figma — AK Design System (JTvfvW2ahlDmuKujonnoyb), exported 2026-10-20
// Regenerate from the Figma variables instead of changing values here.

/// Spacing scale (Figma collection "Spacing"). Even values only.
///
/// Use for padding, gaps and margins: `EdgeInsets.all(AppSpacing.s16)`.
abstract final class AppSpacing {
  static const double s0 = 0;
  static const double s2 = 2;
  static const double s4 = 4;
  static const double s6 = 6;
  static const double s8 = 8;
  static const double s10 = 10;
  static const double s12 = 12;
  static const double s16 = 16;
  static const double s20 = 20;
  static const double s24 = 24;
  static const double s32 = 32;
  static const double s40 = 40;
  static const double s48 = 48;
  static const double s64 = 64;
}
