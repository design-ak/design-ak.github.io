// GENERATED FILE — do not edit by hand.
// Source: Figma — Mobile Design System (JTvfvW2ahlDmuKujonnoyb), exported 2026-10-20
// Regenerate from the Figma variables instead of changing values here.

import 'package:flutter/painting.dart';

/// Corner radius scale (Figma collection "Radius").
///
/// `AppRadius.r8` for a value, `AppRadius.all(AppRadius.r8)` for a [BorderRadius].
abstract final class AppRadius {
  static const double r0 = 0;
  static const double r4 = 4;
  static const double r6 = 6;
  static const double r8 = 8;
  static const double r12 = 12;
  static const double r16 = 16;
  static const double rFull = 999; // pill / circle

  /// Same radius on all four corners.
  static BorderRadius all(double radius) => BorderRadius.all(Radius.circular(radius));

  /// Top corners only — used by bottom sheets (`AppRadius.top(AppRadius.r16)`).
  static BorderRadius top(double radius) => BorderRadius.vertical(top: Radius.circular(radius));
}
