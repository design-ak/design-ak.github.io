// GENERATED FILE — do not edit by hand.
// Source: Figma — AK Design System (JTvfvW2ahlDmuKujonnoyb), exported 2026-10-20
// Regenerate from the Figma variables instead of changing values here.

import 'package:flutter/painting.dart';

/// Elevation shadows (Figma effect styles "Elevation/*").
/// Use as `BoxDecoration(boxShadow: AppShadows.lg)`.
abstract final class AppShadows {
  /// Elevation/Sm — Raised controls (active segmented tab, small cards).
  static const List<BoxShadow> sm = <BoxShadow>[
    BoxShadow(color: Color(0x14000000), offset: Offset(0, 2), blurRadius: 4, spreadRadius: 0),
  ];

  /// Elevation/Lg — Dialogs.
  static const List<BoxShadow> lg = <BoxShadow>[
    BoxShadow(color: Color(0x29000000), offset: Offset(0, 8), blurRadius: 24, spreadRadius: 0),
  ];

  /// Elevation/Sheet — Bottom sheets (shadow casts upward).
  static const List<BoxShadow> sheet = <BoxShadow>[
    BoxShadow(color: Color(0x1F000000), offset: Offset(0, -4), blurRadius: 16, spreadRadius: 0),
  ];
}
