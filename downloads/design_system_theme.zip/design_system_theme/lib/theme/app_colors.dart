// GENERATED FILE — do not edit by hand.
// Source: Figma — Mobile Design System (JTvfvW2ahlDmuKujonnoyb), exported 2026-10-20
// Regenerate from the Figma variables instead of changing values here.

import 'package:flutter/material.dart';

/// Semantic colour tokens (Figma collection "Color", modes Light / Dark).
///
/// Use these, never raw hex values or primitives. Access in widgets with
/// `context.colors.textPrimary` (see [AppColorsContext]).
@immutable
class AppColors extends ThemeExtension<AppColors> {
  const AppColors({
    required this.bgScreen,
    required this.bgSurface,
    required this.bgSurfaceRaised,
    required this.bgDisabled,
    required this.bgPrimarySubtle,
    required this.bgScrim,
    required this.borderSubtle,
    required this.borderDefault,
    required this.borderFocus,
    required this.textPrimary,
    required this.textSecondary,
    required this.textTertiary,
    required this.textDisabled,
    required this.textLink,
    required this.textLinkPressed,
    required this.textOnPrimary,
    required this.iconDefault,
    required this.iconSubtle,
    required this.iconDisabled,
    required this.primaryDefault,
    required this.primaryPressed,
    required this.statusNeutralSurface,
    required this.statusNeutralText,
    required this.statusInfoSurface,
    required this.statusInfoText,
    required this.statusSuccessSurface,
    required this.statusSuccessText,
    required this.statusWarningSurface,
    required this.statusWarningText,
    required this.statusErrorSurface,
    required this.statusErrorText,
    required this.statusPendingSurface,
    required this.statusPendingText,
  });

  /// `bg/screen` — Root screen background. Always white in Light mode (Rule 001).
  final Color bgScreen;

  /// `bg/surface` — Grouped sections, list backgrounds.
  final Color bgSurface;

  /// `bg/surface-raised` — Cards, dialogs and sheets.
  final Color bgSurfaceRaised;

  /// `bg/disabled` — Disabled fills (buttons, inputs).
  final Color bgDisabled;

  /// `bg/primary-subtle` — Light brand tint: selected rows, pressed text buttons.
  final Color bgPrimarySubtle;

  /// `bg/scrim` — Dim layer behind dialogs and bottom sheets (barrierColor).
  final Color bgScrim;

  /// `border/subtle` — Dividers and decorative card borders.
  final Color borderSubtle;

  /// `border/default` — Input and control borders (>= 3:1).
  final Color borderDefault;

  /// `border/focus` — Focus ring / focused input border.
  final Color borderFocus;

  /// `text/primary` — Main text.
  final Color textPrimary;

  /// `text/secondary` — Supporting text, input labels.
  final Color textSecondary;

  /// `text/tertiary` — Placeholders, helper text, meta (>= 4.5:1).
  final Color textTertiary;

  /// `text/disabled` — Disabled text.
  final Color textDisabled;

  /// `text/link` — Links and text buttons.
  final Color textLink;

  /// `text/link-pressed` — Link / text-button label while pressed.
  final Color textLinkPressed;

  /// `text/on-primary` — Text and icons on primary fills. Dark mode uses dark text.
  final Color textOnPrimary;

  /// `icon/default` — Default icon colour.
  final Color iconDefault;

  /// `icon/subtle` — Secondary icons.
  final Color iconSubtle;

  /// `icon/disabled` — Disabled icons.
  final Color iconDisabled;

  /// `primary/default` — Brand fill: primary buttons, active controls.
  final Color primaryDefault;

  /// `primary/pressed` — Pressed state of primary fills.
  final Color primaryPressed;

  /// `status/neutral/surface` — Neutral status background.
  final Color statusNeutralSurface;

  /// `status/neutral/text` — Neutral status text, icon and border.
  final Color statusNeutralText;

  /// `status/info/surface` — Info status background.
  final Color statusInfoSurface;

  /// `status/info/text` — Info status text, icon and border.
  final Color statusInfoText;

  /// `status/success/surface` — Success status background.
  final Color statusSuccessSurface;

  /// `status/success/text` — Success status text, icon and border.
  final Color statusSuccessText;

  /// `status/warning/surface` — Warning status background.
  final Color statusWarningSurface;

  /// `status/warning/text` — Warning status text, icon and border.
  final Color statusWarningText;

  /// `status/error/surface` — Error status background.
  final Color statusErrorSurface;

  /// `status/error/text` — Error status text, icon and border.
  final Color statusErrorText;

  /// `status/pending/surface` — Pending status background.
  final Color statusPendingSurface;

  /// `status/pending/text` — Pending status text, icon and border.
  final Color statusPendingText;

  /// Light mode values.
  static const AppColors light = AppColors(
    bgScreen: Color(0xFFFFFFFF),
    bgSurface: Color(0xFFF5F7F9),
    bgSurfaceRaised: Color(0xFFFFFFFF),
    bgDisabled: Color(0xFFE5EBF1),
    bgPrimarySubtle: Color(0xFFE8F2FB),
    bgScrim: Color(0x800D1117),
    borderSubtle: Color(0xFFE5EBF1),
    borderDefault: Color(0xFF878E95),
    borderFocus: Color(0xFF1677D6),
    textPrimary: Color(0xFF0D1117),
    textSecondary: Color(0xFF43484D),
    textTertiary: Color(0xFF6B7177),
    textDisabled: Color(0xFFC2C9CE),
    textLink: Color(0xFF1677D6),
    textLinkPressed: Color(0xFF1365B6),
    textOnPrimary: Color(0xFFFFFFFF),
    iconDefault: Color(0xFF43484D),
    iconSubtle: Color(0xFF6B7177),
    iconDisabled: Color(0xFFC2C9CE),
    primaryDefault: Color(0xFF1677D6),
    primaryPressed: Color(0xFF1365B6),
    statusNeutralSurface: Color(0xFFE5EBF1),
    statusNeutralText: Color(0xFF43484D),
    statusInfoSurface: Color(0xFFE8F2FB),
    statusInfoText: Color(0xFF1365B6),
    statusSuccessSurface: Color(0xFFE9F8F3),
    statusSuccessText: Color(0xFF107A61),
    statusWarningSurface: Color(0xFFFFF8DA),
    statusWarningText: Color(0xFF826400),
    statusErrorSurface: Color(0xFFFCEEEF),
    statusErrorText: Color(0xFFB83C45),
    statusPendingSurface: Color(0xFFF3EFFC),
    statusPendingText: Color(0xFF6346BF),
  );

  /// Dark mode values.
  static const AppColors dark = AppColors(
    bgScreen: Color(0xFF0D1117),
    bgSurface: Color(0xFF161B22),
    bgSurfaceRaised: Color(0xFF21262D),
    bgDisabled: Color(0xFF21262D),
    bgPrimarySubtle: Color(0xFF12202E),
    bgScrim: Color(0xB2000000),
    borderSubtle: Color(0xFF30363D),
    borderDefault: Color(0xFF6B7177),
    borderFocus: Color(0xFF3FA5F9),
    textPrimary: Color(0xFFF5F7F9),
    textSecondary: Color(0xFFC2C9CE),
    textTertiary: Color(0xFF878E95),
    textDisabled: Color(0xFF43484D),
    textLink: Color(0xFF3FA5F9),
    textLinkPressed: Color(0xFF3FA5F9),
    textOnPrimary: Color(0xFF0D1117),
    iconDefault: Color(0xFFC2C9CE),
    iconSubtle: Color(0xFF878E95),
    iconDisabled: Color(0xFF43484D),
    primaryDefault: Color(0xFF3FA5F9),
    primaryPressed: Color(0xFF2F8FE8),
    statusNeutralSurface: Color(0xFF21262D),
    statusNeutralText: Color(0xFFC2C9CE),
    statusInfoSurface: Color(0xFF12202E),
    statusInfoText: Color(0xFF3FA5F9),
    statusSuccessSurface: Color(0xFF102C26),
    statusSuccessText: Color(0xFF2DD4A8),
    statusWarningSurface: Color(0xFF302A16),
    statusWarningText: Color(0xFFFFD54F),
    statusErrorSurface: Color(0xFF321D23),
    statusErrorText: Color(0xFFF07178),
    statusPendingSurface: Color(0xFF211B30),
    statusPendingText: Color(0xFFB79CFF),
  );

  @override
  AppColors copyWith({
    Color? bgScreen,
    Color? bgSurface,
    Color? bgSurfaceRaised,
    Color? bgDisabled,
    Color? bgPrimarySubtle,
    Color? bgScrim,
    Color? borderSubtle,
    Color? borderDefault,
    Color? borderFocus,
    Color? textPrimary,
    Color? textSecondary,
    Color? textTertiary,
    Color? textDisabled,
    Color? textLink,
    Color? textLinkPressed,
    Color? textOnPrimary,
    Color? iconDefault,
    Color? iconSubtle,
    Color? iconDisabled,
    Color? primaryDefault,
    Color? primaryPressed,
    Color? statusNeutralSurface,
    Color? statusNeutralText,
    Color? statusInfoSurface,
    Color? statusInfoText,
    Color? statusSuccessSurface,
    Color? statusSuccessText,
    Color? statusWarningSurface,
    Color? statusWarningText,
    Color? statusErrorSurface,
    Color? statusErrorText,
    Color? statusPendingSurface,
    Color? statusPendingText,
  }) {
    return AppColors(
      bgScreen: bgScreen ?? this.bgScreen,
      bgSurface: bgSurface ?? this.bgSurface,
      bgSurfaceRaised: bgSurfaceRaised ?? this.bgSurfaceRaised,
      bgDisabled: bgDisabled ?? this.bgDisabled,
      bgPrimarySubtle: bgPrimarySubtle ?? this.bgPrimarySubtle,
      bgScrim: bgScrim ?? this.bgScrim,
      borderSubtle: borderSubtle ?? this.borderSubtle,
      borderDefault: borderDefault ?? this.borderDefault,
      borderFocus: borderFocus ?? this.borderFocus,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      textTertiary: textTertiary ?? this.textTertiary,
      textDisabled: textDisabled ?? this.textDisabled,
      textLink: textLink ?? this.textLink,
      textLinkPressed: textLinkPressed ?? this.textLinkPressed,
      textOnPrimary: textOnPrimary ?? this.textOnPrimary,
      iconDefault: iconDefault ?? this.iconDefault,
      iconSubtle: iconSubtle ?? this.iconSubtle,
      iconDisabled: iconDisabled ?? this.iconDisabled,
      primaryDefault: primaryDefault ?? this.primaryDefault,
      primaryPressed: primaryPressed ?? this.primaryPressed,
      statusNeutralSurface: statusNeutralSurface ?? this.statusNeutralSurface,
      statusNeutralText: statusNeutralText ?? this.statusNeutralText,
      statusInfoSurface: statusInfoSurface ?? this.statusInfoSurface,
      statusInfoText: statusInfoText ?? this.statusInfoText,
      statusSuccessSurface: statusSuccessSurface ?? this.statusSuccessSurface,
      statusSuccessText: statusSuccessText ?? this.statusSuccessText,
      statusWarningSurface: statusWarningSurface ?? this.statusWarningSurface,
      statusWarningText: statusWarningText ?? this.statusWarningText,
      statusErrorSurface: statusErrorSurface ?? this.statusErrorSurface,
      statusErrorText: statusErrorText ?? this.statusErrorText,
      statusPendingSurface: statusPendingSurface ?? this.statusPendingSurface,
      statusPendingText: statusPendingText ?? this.statusPendingText,
    );
  }

  @override
  AppColors lerp(covariant ThemeExtension<AppColors>? other, double t) {
    if (other is! AppColors) return this;
    return AppColors(
      bgScreen: Color.lerp(bgScreen, other.bgScreen, t)!,
      bgSurface: Color.lerp(bgSurface, other.bgSurface, t)!,
      bgSurfaceRaised: Color.lerp(bgSurfaceRaised, other.bgSurfaceRaised, t)!,
      bgDisabled: Color.lerp(bgDisabled, other.bgDisabled, t)!,
      bgPrimarySubtle: Color.lerp(bgPrimarySubtle, other.bgPrimarySubtle, t)!,
      bgScrim: Color.lerp(bgScrim, other.bgScrim, t)!,
      borderSubtle: Color.lerp(borderSubtle, other.borderSubtle, t)!,
      borderDefault: Color.lerp(borderDefault, other.borderDefault, t)!,
      borderFocus: Color.lerp(borderFocus, other.borderFocus, t)!,
      textPrimary: Color.lerp(textPrimary, other.textPrimary, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      textTertiary: Color.lerp(textTertiary, other.textTertiary, t)!,
      textDisabled: Color.lerp(textDisabled, other.textDisabled, t)!,
      textLink: Color.lerp(textLink, other.textLink, t)!,
      textLinkPressed: Color.lerp(textLinkPressed, other.textLinkPressed, t)!,
      textOnPrimary: Color.lerp(textOnPrimary, other.textOnPrimary, t)!,
      iconDefault: Color.lerp(iconDefault, other.iconDefault, t)!,
      iconSubtle: Color.lerp(iconSubtle, other.iconSubtle, t)!,
      iconDisabled: Color.lerp(iconDisabled, other.iconDisabled, t)!,
      primaryDefault: Color.lerp(primaryDefault, other.primaryDefault, t)!,
      primaryPressed: Color.lerp(primaryPressed, other.primaryPressed, t)!,
      statusNeutralSurface: Color.lerp(statusNeutralSurface, other.statusNeutralSurface, t)!,
      statusNeutralText: Color.lerp(statusNeutralText, other.statusNeutralText, t)!,
      statusInfoSurface: Color.lerp(statusInfoSurface, other.statusInfoSurface, t)!,
      statusInfoText: Color.lerp(statusInfoText, other.statusInfoText, t)!,
      statusSuccessSurface: Color.lerp(statusSuccessSurface, other.statusSuccessSurface, t)!,
      statusSuccessText: Color.lerp(statusSuccessText, other.statusSuccessText, t)!,
      statusWarningSurface: Color.lerp(statusWarningSurface, other.statusWarningSurface, t)!,
      statusWarningText: Color.lerp(statusWarningText, other.statusWarningText, t)!,
      statusErrorSurface: Color.lerp(statusErrorSurface, other.statusErrorSurface, t)!,
      statusErrorText: Color.lerp(statusErrorText, other.statusErrorText, t)!,
      statusPendingSurface: Color.lerp(statusPendingSurface, other.statusPendingSurface, t)!,
      statusPendingText: Color.lerp(statusPendingText, other.statusPendingText, t)!,
    );
  }
}

/// `context.colors.bgScreen` — shorthand for the current theme's [AppColors].
extension AppColorsContext on BuildContext {
  AppColors get colors {
    final AppColors? colors = Theme.of(this).extension<AppColors>();
    assert(colors != null, 'AppColors not found: use AppTheme.light() / AppTheme.dark().');
    return colors!;
  }
}
