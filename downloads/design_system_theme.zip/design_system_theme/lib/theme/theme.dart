// GENERATED FILE — do not edit by hand.
// Source: Figma — Mobile Design System (JTvfvW2ahlDmuKujonnoyb), exported 2026-10-20
// Regenerate from the Figma variables instead of changing values here.
export 'app_colors.dart';
export 'app_radius.dart';
export 'app_shadows.dart';
export 'app_spacing.dart';
export 'app_theme.dart';
export 'app_typography.dart';
