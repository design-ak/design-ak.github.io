// GENERATED FILE — do not edit by hand.
// Source: Figma — Mobile Design System (JTvfvW2ahlDmuKujonnoyb), exported 2026-10-20
// Regenerate from the Figma variables instead of changing values here.

import 'package:flutter/painting.dart';

/// Text styles (Figma text styles, bound to the "Typography" variables).
///
/// English renders in Roboto; Gujarati and Hindi characters fall back to
/// Noto Sans Gujarati / Noto Sans Devanagari at the same size and line height.
/// Styles carry no colour: apply one from [AppColors], e.g.
/// `AppTypography.bodyMd.copyWith(color: context.colors.textSecondary)`.
abstract final class AppTypography {
  /// Family names must match the `family:` entries in pubspec.yaml.
  static const String fontFamily = 'Roboto';
  static const List<String> fontFamilyFallback = <String>['Noto Sans Gujarati', 'Noto Sans Devanagari'];

  /// Heading/H1 — 32/40 SemiBold. Screen titles.
  static const TextStyle h1 = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 32,
    height: 40 / 32,
    fontWeight: FontWeight.w600,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Heading/H1 Bold — 32/40 Bold. Screen titles, strong emphasis.
  static const TextStyle h1Bold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 32,
    height: 40 / 32,
    fontWeight: FontWeight.w700,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Heading/H2 — 24/32 SemiBold. Section titles.
  static const TextStyle h2 = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 24,
    height: 32 / 24,
    fontWeight: FontWeight.w600,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Heading/H2 Bold — 24/32 Bold. Section titles, strong emphasis.
  static const TextStyle h2Bold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 24,
    height: 32 / 24,
    fontWeight: FontWeight.w700,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Heading/H3 — 20/28 SemiBold. Card titles, sheet and dialog titles.
  static const TextStyle h3 = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 20,
    height: 28 / 20,
    fontWeight: FontWeight.w600,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Heading/H3 Bold — 20/28 Bold. Card titles, strong emphasis.
  static const TextStyle h3Bold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 20,
    height: 28 / 20,
    fontWeight: FontWeight.w700,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Heading/H4 — 18/26 SemiBold. Sub-section titles, bottom sheet titles.
  static const TextStyle h4 = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 18,
    height: 26 / 18,
    fontWeight: FontWeight.w600,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Heading/H4 Bold — 18/26 Bold. Sub-section titles, strong emphasis.
  static const TextStyle h4Bold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 18,
    height: 26 / 18,
    fontWeight: FontWeight.w700,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Body/Lg — 18/28 Regular. Lead paragraphs.
  static const TextStyle bodyLg = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 18,
    height: 28 / 18,
    fontWeight: FontWeight.w400,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Body/Lg Bold — 18/28 Bold. Lead paragraphs, strong emphasis.
  static const TextStyle bodyLgBold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 18,
    height: 28 / 18,
    fontWeight: FontWeight.w700,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Body/Md — 16/24 Regular. Default body text, input values.
  static const TextStyle bodyMd = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 16,
    height: 24 / 16,
    fontWeight: FontWeight.w400,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Body/Md Strong — 16/24 SemiBold. Emphasis in body, list item titles, selected options.
  static const TextStyle bodyMdStrong = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 16,
    height: 24 / 16,
    fontWeight: FontWeight.w600,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Body/Md Bold — 16/24 Bold. Strong emphasis in body.
  static const TextStyle bodyMdBold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 16,
    height: 24 / 16,
    fontWeight: FontWeight.w700,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Body/Sm — 14/22 Regular. Secondary text, descriptions.
  static const TextStyle bodySm = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 14,
    height: 22 / 14,
    fontWeight: FontWeight.w400,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Body/Sm Strong — 14/22 SemiBold. Emphasis in small text.
  static const TextStyle bodySmStrong = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 14,
    height: 22 / 14,
    fontWeight: FontWeight.w600,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Body/Sm Bold — 14/22 Bold. Strong emphasis in small text.
  static const TextStyle bodySmBold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 14,
    height: 22 / 14,
    fontWeight: FontWeight.w700,
    letterSpacing: 0,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Label — 12/18 SemiBold. Input labels, badges.
  static const TextStyle label = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 12,
    height: 18 / 12,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.2,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Label Bold — 12/18 Bold. Labels, strong emphasis.
  static const TextStyle labelBold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 12,
    height: 18 / 12,
    fontWeight: FontWeight.w700,
    letterSpacing: 0.2,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Caption — 12/18 Regular. Helper text, timestamps, meta.
  static const TextStyle caption = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 12,
    height: 18 / 12,
    fontWeight: FontWeight.w400,
    letterSpacing: 0.2,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Caption Bold — 12/18 Bold. Captions, strong emphasis.
  static const TextStyle captionBold = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 12,
    height: 18 / 12,
    fontWeight: FontWeight.w700,
    letterSpacing: 0.2,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Button/Lg — 16/24 SemiBold. Large buttons (48).
  static const TextStyle buttonLg = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 16,
    height: 24 / 16,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.2,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Button/Md — 14/20 SemiBold. Medium buttons (40), tabs.
  static const TextStyle buttonMd = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 14,
    height: 20 / 14,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.2,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Button/Sm — 12/18 SemiBold. Small buttons (32).
  static const TextStyle buttonSm = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 12,
    height: 18 / 12,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.2,
    leadingDistribution: TextLeadingDistribution.even,
  );

  /// Button/Xs — 10/14 SemiBold. Extra-small buttons (24).
  static const TextStyle buttonXs = TextStyle(
    fontFamily: fontFamily,
    fontFamilyFallback: fontFamilyFallback,
    fontSize: 10,
    height: 14 / 10,
    fontWeight: FontWeight.w600,
    letterSpacing: 0.2,
    leadingDistribution: TextLeadingDistribution.even,
  );
}
