// GENERATED FILE — do not edit by hand.
// Source: Figma — AK Design System (JTvfvW2ahlDmuKujonnoyb), exported 2026-10-20
// Regenerate from the Figma variables instead of changing values here.
import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'app_radius.dart';
import 'app_typography.dart';

/// Builds Material [ThemeData] for Light and Dark from the design tokens.
///
/// ```dart
/// MaterialApp(
///   theme: AppTheme.light(),
///   darkTheme: AppTheme.dark(),
///   themeMode: ThemeMode.system,
/// );
/// ```
///
/// Material widgets pick up the mapped [ColorScheme] and [TextTheme]; custom
/// widgets should read tokens directly via `context.colors` and [AppTypography].
abstract final class AppTheme {
  static ThemeData light() => _build(Brightness.light, AppColors.light);
  static ThemeData dark() => _build(Brightness.dark, AppColors.dark);

  static ThemeData _build(Brightness brightness, AppColors c) {
    final ColorScheme scheme = ColorScheme(
      brightness: brightness,
      primary: c.primaryDefault,
      onPrimary: c.textOnPrimary,
      primaryContainer: c.bgPrimarySubtle,
      onPrimaryContainer: c.textLink,
      secondary: c.primaryDefault,
      onSecondary: c.textOnPrimary,
      secondaryContainer: c.bgPrimarySubtle,
      onSecondaryContainer: c.textLink,
      error: c.statusErrorText,
      onError: c.bgScreen,
      errorContainer: c.statusErrorSurface,
      onErrorContainer: c.statusErrorText,
      surface: c.bgScreen,
      onSurface: c.textPrimary,
      // Material 3 dialogs, cards, menus and sheets read these container colours.
      surfaceContainerLowest: c.bgScreen,
      surfaceContainerLow: c.bgSurface,
      surfaceContainer: c.bgSurface,
      surfaceContainerHigh: c.bgSurfaceRaised,
      surfaceContainerHighest: c.bgSurfaceRaised,
      surfaceTint: Colors.transparent,
      onSurfaceVariant: c.textSecondary,
      outline: c.borderDefault,
      outlineVariant: c.borderSubtle,
      scrim: c.bgScrim,
    );

    final TextTheme textTheme = const TextTheme(
      headlineLarge: AppTypography.h1,
      headlineMedium: AppTypography.h2,
      titleLarge: AppTypography.h3,
      titleMedium: AppTypography.h4,
      bodyLarge: AppTypography.bodyMd,
      bodyMedium: AppTypography.bodySm,
      bodySmall: AppTypography.caption,
      labelLarge: AppTypography.buttonMd,
      labelMedium: AppTypography.label,
      labelSmall: AppTypography.caption,
    ).apply(bodyColor: c.textPrimary, displayColor: c.textPrimary);

    return ThemeData(
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: c.bgScreen,
      canvasColor: c.bgScreen,
      dividerColor: c.borderSubtle,
      fontFamily: AppTypography.fontFamily,
      fontFamilyFallback: AppTypography.fontFamilyFallback,
      textTheme: textTheme,
      // Keep 48px touch targets even for 24–40px tall buttons (Rule 005).
      materialTapTargetSize: MaterialTapTargetSize.padded,
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: c.bgSurfaceRaised,
        modalBackgroundColor: c.bgSurfaceRaised,
        modalBarrierColor: c.bgScrim,
        showDragHandle: true,
        dragHandleColor: c.borderDefault,
        shape: RoundedRectangleBorder(borderRadius: AppRadius.top(AppRadius.r16)),
        clipBehavior: Clip.antiAlias,
      ),
      extensions: <ThemeExtension<dynamic>>[c],
    );
  }
}
